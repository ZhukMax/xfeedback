<?php
require_once (dirname(dirname(__FILE__)) . '/xfeedbackitem.class.php');
class xFeedbackItem_mysql extends xFeedbackItem {}