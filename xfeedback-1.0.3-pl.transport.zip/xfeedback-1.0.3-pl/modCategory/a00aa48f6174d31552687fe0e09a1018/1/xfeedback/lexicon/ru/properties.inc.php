<?php

$_lang['xfeedback_prop_limit'] = 'Ограничение вывода комментариев на странице.';
$_lang['xfeedback_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['xfeedback_prop_sortBy'] = 'Поле сортировки.';
$_lang['xfeedback_prop_sortDir'] = 'Направление сортировки.';
$_lang['xfeedback_prop_tpl'] = 'Чанк оформления каждого ряда комментариев.';
$_lang['xfeedback_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
