--------------------
xFeedback
--------------------
Author: Max Zhuk <zhukmax@ya.ru>
--------------------

A basic Extra for MODx Revolution.