<?php
class xFeedbackItem extends xPDOSimpleObject {}