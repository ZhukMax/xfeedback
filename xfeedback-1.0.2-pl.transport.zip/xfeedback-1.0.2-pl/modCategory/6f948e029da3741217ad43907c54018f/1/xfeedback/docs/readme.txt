--------------------
xFeedback
--------------------
Author: Max Zhuk <zhukmax@ya.ru>
--------------------

Extra for MODx Revolution.
