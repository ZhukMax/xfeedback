<?php

$_lang['area_xfeedback_main'] = 'Основные';

$_lang['setting_xfeedback_some_setting'] = 'Какая-то настройка';
$_lang['setting_xfeedback_some_setting_desc'] = 'Это описание для какой-то настройки';