<?php

switch ($modx->event->name) {

}